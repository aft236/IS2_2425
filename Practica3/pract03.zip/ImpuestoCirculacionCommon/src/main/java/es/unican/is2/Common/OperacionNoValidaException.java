package es.unican.is2.Common;

@SuppressWarnings("serial")
public class OperacionNoValidaException extends RuntimeException {

	public OperacionNoValidaException(String string) {
		super(string);
	}

}
